"use client";
import { STAGES, stageIndex } from "../lib/workflow";
const LABEL={registered:"Registration",nursing:"Nurse Screening",doctor:"Doctor Exam",prescription:"Prescription",pharmacy:"Pharmacy",billing:"Billing",followup:"Follow-up",closed:"Close Visit"};
export default function WorkflowBar({stage}){
  const at=stageIndex(stage);
  return <div className="workflow-bar">{STAGES.map((s,i)=><div key={s} className={`workflow-step ${i<at?"done":""} ${i===at?"active":""}`}><span>{i+1}</span><small>{LABEL[s]}</small></div>)}</div>;
}
