"use client";
import Link from "next/link";
import { usePathname,useRouter } from "next/navigation";
import { useLanguage } from "../lib/i18n";
import { useRole } from "../lib/role";
const PAGES=[
 {key:"dashboard",href:"/dashboard",label:"Dashboard"},{key:"patients",href:"/patients",label:"Patients"},{key:"bookings",href:"/bookings",label:"Registration"},
 {key:"nursing",href:"/nursing",label:"Nurse"},{key:"doctor_work",href:"/doctor",label:"Doctor"},{key:"prescriptions",href:"/prescriptions",label:"Rx"},
 {key:"pharmacy",href:"/pharmacy",label:"Pharmacy"},{key:"billing",href:"/billing",label:"Billing"},{key:"followup",href:"/follow-up",label:"Follow-up"},
 {key:"close_visit",href:"/close-visit",label:"Close Visit"},{key:"strabismus",href:"/strabismus",label:"Surgery Calc"},{key:"quality",href:"/quality",label:"Quality"},{key:"queue_tv",href:"/queue",label:"Queue TV"}
];
export default function Nav(){
 const {lang,setLang,t}=useLanguage(); const {role,staffName,canAccess,logout}=useRole(); const pathname=usePathname(); const router=useRouter();
 if(pathname==="/login"||pathname==="/") return <header className="topbar"><div className="brand"><span className="brand-badge">DJ</span><span>{t("clinic_name")}</span></div><div className="lang-switch">{["lo","th","en"].map(l=><button key={l} className={"lang-btn"+(lang===l?" active":"")} onClick={()=>setLang(l)}>{l.toUpperCase()}</button>)}</div></header>;
 const visible=PAGES.filter(p=>p.key==="queue_tv"||canAccess(p.key));
 return <header className="topbar"><div className="brand"><span className="brand-badge">DJ</span><span>{t("clinic_name")}</span><em>SMART CLINIC OS</em></div><nav className="nav-links">{visible.map(p=><Link key={p.key} href={p.href} className={"nav-link"+(pathname.startsWith(p.href)?" active":"")}>{t(p.key)!==p.key?t(p.key):p.label}</Link>)}</nav><div className="topbar-right"><div className="lang-switch">{["lo","th","en"].map(l=><button key={l} className={"lang-btn"+(lang===l?" active":"")} onClick={()=>setLang(l)}>{l.toUpperCase()}</button>)}</div>{role&&<div className="staff-chip">{staffName?`${staffName} · `:""}{t("role_"+role)}</div>}{role&&<button className="logout-btn" onClick={()=>{logout();router.push("/login")}}>{t("logout")}</button>}</div></header>;
}
