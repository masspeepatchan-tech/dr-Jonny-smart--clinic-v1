"use client";
import { useEffect } from "react";
import { usePathname, useRouter } from "next/navigation";
import { useRole } from "../lib/role";

export default function AuthGuard({children}){
  const {role}=useRole(); const path=usePathname(); const router=useRouter();
  const publicPath=path==="/"||path==="/login"||path==="/queue";
  useEffect(()=>{ if(!publicPath && role===null) router.replace("/login"); },[publicPath,role,router]);
  if(!publicPath && !role) return <div className="spinner-text">Authorizing…</div>;
  return children;
}
