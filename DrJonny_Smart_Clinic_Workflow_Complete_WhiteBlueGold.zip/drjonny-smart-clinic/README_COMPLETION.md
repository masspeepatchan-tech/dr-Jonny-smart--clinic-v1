# Dr. Jonny Smart Clinic OS — Workflow Completion Build

This build CONTINUES the supplied Next.js codebase; it does not rebuild from scratch.

## Added / completed
- Registration / Booking → Nurse Screening → Doctor Exam → Prescription → Pharmacy → Billing → Follow-up → Close Visit
- Client-side Role Access: Admin, Doctor, Nurse, Reception, Pharmacy, Cashier
- Eye + ENT screening/exam fields
- Visual Acuity guided select and OD/OS/OU explanation
- IOP OD/OS + NCT / Goldmann / iCare
- Nurse-to-Doctor clinical handoff summary
- Prescription order builder with eye/ENT common medication list
- Pharmacy verification + preparation handoff
- Billing payment gate
- Follow-up plan
- Close Visit safety checklist
- Live Patient Journey board on dashboard
- Strabismus Surgery Reference Calculator with surgeon confirmation
- Quality Management Center document map
- White / Blue / Gold corporate clinic UI

## Data architecture in this build
Existing patients, bookings, stock and transactions continue using the supplied Supabase integration.
The new cross-station encounter workflow uses browser localStorage (`dj_encounters_v2`) to avoid requiring new Supabase tables before demo/UAT.

For production multi-device use, move the encounter workflow to Supabase tables with RLS, authentication, server-side audit logs and data-protection controls.

## Run
npm install
npm run dev

## Deploy
Set NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY in Vercel project environment settings, then deploy the project root.
