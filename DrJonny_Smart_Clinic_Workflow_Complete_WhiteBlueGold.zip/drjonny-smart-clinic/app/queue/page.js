"use client";
import { useEffect, useState } from "react";
import { supabase } from "../../lib/supabaseClient";
import { useLanguage } from "../../lib/i18n";

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

export default function QueuePage() {
  const { t, lang } = useLanguage();
  const [bookings, setBookings] = useState([]);
  const [clock, setClock] = useState(new Date());

  async function load() {
    const { data } = await supabase
      .from("drjonny_bookings")
      .select("id, name, service, booking_time, status")
      .eq("booking_date", todayStr())
      .in("status", ["pending", "confirmed", "done"])
      .order("booking_time", { ascending: true });
    setBookings(data || []);
  }

  useEffect(() => {
    load();
    const poll = setInterval(load, 8000);
    const clockTimer = setInterval(() => setClock(new Date()), 1000);

    const channel = supabase
      .channel("drjonny_queue")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "drjonny_bookings" },
        () => load()
      )
      .subscribe();

    return () => {
      clearInterval(poll);
      clearInterval(clockTimer);
      supabase.removeChannel(channel);
    };
  }, []);

  const currentIdx = bookings.findIndex((b) => b.status === "confirmed");

  return (
    <div className="tv-wrap">
      <div className="tv-header">
        <div className="tv-title">🏥 Dr. Jonny Smart Clinic — {t("queue_tv")}</div>
        <div className="tv-clock">
          {clock.toLocaleTimeString(lang === "en" ? "en-US" : "lo-LA", { hour: "2-digit", minute: "2-digit" })}
        </div>
      </div>

      {bookings.length === 0 && (
        <div style={{ textAlign: "center", padding: "80px 0", opacity: 0.7, fontSize: 20 }}>
          {t("no_data")}
        </div>
      )}

      <div className="tv-grid">
        {bookings.map((b, i) => (
          <div key={b.id} className={"tv-card" + (i === currentIdx ? " current" : "")}>
            <div className="tv-time">{b.booking_time?.slice(0, 5)}</div>
            <div className="tv-name">{b.name}</div>
            <div className="tv-service">{b.service || "-"}</div>
            <div className="tv-status">
              <span className={"badge badge-" + b.status}>{t("status_" + b.status)}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
