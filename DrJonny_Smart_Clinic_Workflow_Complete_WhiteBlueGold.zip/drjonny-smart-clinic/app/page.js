"use client";
import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useRole } from "../lib/role";

export default function Home() {
  const router = useRouter();
  const { role } = useRole();

  useEffect(() => {
    const t = setTimeout(() => {
      router.replace(role ? "/dashboard" : "/login");
    }, 50);
    return () => clearTimeout(t);
  }, [role, router]);

  return <div className="spinner-text">Loading…</div>;
}
