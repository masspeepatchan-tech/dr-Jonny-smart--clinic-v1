"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabaseClient";
import { useLanguage } from "../../lib/i18n";

export default function ExamsPage() {
  const { t } = useLanguage();
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const { data } = await supabase
        .from("drjonny_eye_exams")
        .select("id, patient_id, diagnosis, examined_by, examined_at, visual_acuity_od, visual_acuity_os")
        .order("examined_at", { ascending: false })
        .limit(100);
      setExams(data || []);
      setLoading(false);
    }
    load();
  }, []);

  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="page-title">{t("exams")}</h1>
          <p className="page-sub">{t("exam_history")}</p>
        </div>
        <Link href="/bookings" className="btn btn-primary">
          + {t("eye_exam_form")}
        </Link>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>{t("date")}</th>
              <th>{t("od")}</th>
              <th>{t("os")}</th>
              <th>{t("diagnosis")}</th>
              <th>{t("examined_by")}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {!loading && exams.length === 0 && (
              <tr><td colSpan={6} className="spinner-text">{t("no_data")}</td></tr>
            )}
            {exams.map((ex) => (
              <tr key={ex.id}>
                <td>{ex.examined_at?.slice(0, 10)}</td>
                <td>{ex.visual_acuity_od || "-"}</td>
                <td>{ex.visual_acuity_os || "-"}</td>
                <td>{ex.diagnosis || "-"}</td>
                <td>{ex.examined_by || "-"}</td>
                <td>
                  {ex.patient_id && (
                    <Link href={`/patients/${ex.patient_id}`} className="link-btn">
                      {t("view")} →
                    </Link>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
