"use client";
import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { supabase } from "../../../lib/supabaseClient";
import { useLanguage } from "../../../lib/i18n";

const emptyForm = {
  visual_acuity_od: "",
  visual_acuity_os: "",
  auto_refraction_od: "",
  auto_refraction_os: "",
  iop_od: "",
  iop_os: "",
  slit_lamp_findings: "",
  diagnosis: "",
  treatment_plan: "",
  examined_by: "",
};

function ExamForm() {
  const { t } = useLanguage();
  const router = useRouter();
  const params = useSearchParams();
  const bookingId = params.get("booking_id");
  const patientId = params.get("patient_id");
  const name = params.get("name");

  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError("");
    const payload = { ...form };
    Object.keys(payload).forEach((k) => {
      if (payload[k] === "") payload[k] = null;
    });
    if (bookingId) payload.booking_id = Number(bookingId);
    if (patientId) payload.patient_id = Number(patientId);
    const { error } = await supabase.from("drjonny_eye_exams").insert(payload);
    setSaving(false);
    if (error) {
      setError(error.message);
      return;
    }
    setDone(true);
    setTimeout(() => router.push("/exams"), 1200);
  }

  return (
    <div>
      <h1 className="page-title">{t("eye_exam_form")}</h1>
      <p className="page-sub">{name ? decodeURIComponent(name) : ""}</p>

      {done ? (
        <div className="card">✅ {t("save")} — OK</div>
      ) : (
        <form onSubmit={handleSave} className="card">
          <h3 style={{ marginTop: 0, color: "var(--navy)", fontSize: 14 }}>{t("visual_acuity")}</h3>
          <div className="form-grid">
            <div className="field">
              <label>{t("od")}</label>
              <input value={form.visual_acuity_od} onChange={(e) => setForm({ ...form, visual_acuity_od: e.target.value })} placeholder="6/6" />
            </div>
            <div className="field">
              <label>{t("os")}</label>
              <input value={form.visual_acuity_os} onChange={(e) => setForm({ ...form, visual_acuity_os: e.target.value })} placeholder="6/6" />
            </div>
          </div>

          <h3 style={{ color: "var(--navy)", fontSize: 14 }}>{t("auto_refraction")}</h3>
          <div className="form-grid">
            <div className="field">
              <label>{t("od")}</label>
              <input value={form.auto_refraction_od} onChange={(e) => setForm({ ...form, auto_refraction_od: e.target.value })} placeholder="-1.00 DS" />
            </div>
            <div className="field">
              <label>{t("os")}</label>
              <input value={form.auto_refraction_os} onChange={(e) => setForm({ ...form, auto_refraction_os: e.target.value })} placeholder="-1.00 DS" />
            </div>
          </div>

          <h3 style={{ color: "var(--navy)", fontSize: 14 }}>{t("iop")} (mmHg)</h3>
          <div className="form-grid">
            <div className="field">
              <label>{t("od")}</label>
              <input type="number" step="0.1" value={form.iop_od} onChange={(e) => setForm({ ...form, iop_od: e.target.value })} />
            </div>
            <div className="field">
              <label>{t("os")}</label>
              <input type="number" step="0.1" value={form.iop_os} onChange={(e) => setForm({ ...form, iop_os: e.target.value })} />
            </div>
          </div>

          <div className="field" style={{ marginBottom: 14 }}>
            <label>{t("slit_lamp")}</label>
            <textarea rows={2} value={form.slit_lamp_findings} onChange={(e) => setForm({ ...form, slit_lamp_findings: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 14 }}>
            <label>{t("diagnosis")}</label>
            <textarea rows={2} value={form.diagnosis} onChange={(e) => setForm({ ...form, diagnosis: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 14 }}>
            <label>{t("treatment_plan")}</label>
            <textarea rows={2} value={form.treatment_plan} onChange={(e) => setForm({ ...form, treatment_plan: e.target.value })} />
          </div>
          <div className="field" style={{ marginBottom: 16, maxWidth: 300 }}>
            <label>{t("examined_by")}</label>
            <input value={form.examined_by} onChange={(e) => setForm({ ...form, examined_by: e.target.value })} />
          </div>

          {error && <div className="note-box" style={{ marginBottom: 12 }}>{error}</div>}

          <button className="btn btn-primary" type="submit" disabled={saving}>
            {saving ? "…" : t("save")}
          </button>
        </form>
      )}
    </div>
  );
}

export default function NewExamPage() {
  return (
    <Suspense fallback={<div className="spinner-text">Loading…</div>}>
      <ExamForm />
    </Suspense>
  );
}
