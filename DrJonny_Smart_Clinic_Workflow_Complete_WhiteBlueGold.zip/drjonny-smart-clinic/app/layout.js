import "./globals.css";
import { LanguageProvider } from "../lib/i18n";
import { RoleProvider } from "../lib/role";
import Nav from "../components/Nav";
import AuthGuard from "../components/AuthGuard";
export const metadata={title:"Dr. Jonny Smart Clinic OS",description:"Eye + ENT Smart Clinic Operating System, Vientiane, Laos"};
export default function RootLayout({children}){return <html lang="lo"><body><LanguageProvider><RoleProvider><div className="app-shell"><Nav/><main className="main"><AuthGuard>{children}</AuthGuard></main></div></RoleProvider></LanguageProvider></body></html>}
