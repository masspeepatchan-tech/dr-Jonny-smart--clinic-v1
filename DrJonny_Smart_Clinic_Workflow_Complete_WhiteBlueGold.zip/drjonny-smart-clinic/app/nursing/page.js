"use client";
import { Suspense,useEffect,useState } from "react";
import { useSearchParams,useRouter } from "next/navigation";
import WorkflowBar from "../../components/WorkflowBar";
import { ensureEncounter,getEncounter,listEncounters,updateEncounter } from "../../lib/workflow";
import { useRole } from "../../lib/role";

const VA=["6/6 (20/20)","6/9 (20/30)","6/12 (20/40)","6/18 (20/60)","6/24 (20/80)","6/36 (20/120)","6/60 (20/200)","CF","HM","LP","NLP"];
function Page(){
 const q=useSearchParams(),router=useRouter(),{staffName}=useRole(); const id=q.get("encounter_id")||q.get("booking_id");
 const [enc,setEnc]=useState(null); const [rows,setRows]=useState([]); const [f,setF]=useState({chief_complaint:"",duration:"",esi:"3",emergency_red_flags:"none",bp:"",hr:"",rr:"",temp:"",spo2:"",pain:"0",va_od:"",va_os:"",eye_side:"OU",eye_symptoms:"",ent_symptoms:"",allergy_review:"",nurse_note:""});
 useEffect(()=>{setRows(listEncounters().filter(x=>x.stage!=="closed")); if(id){const e=getEncounter(id)||ensureEncounter({id,name:q.get("name")||""});setEnc(e);setF(v=>({...v,...(e.nursing||{})}));}},[id,q]);
 function choose(e){setEnc(e);setF(v=>({...v,...(e.nursing||{})}));router.replace(`/nursing?encounter_id=${e.id}&name=${encodeURIComponent(e.name)}`)}
 function save(e){e.preventDefault();const next=updateEncounter(enc.id,{nursing:{...f,recorded_at:new Date().toISOString(),recorded_by:staffName||"Nurse"}},"nursing",staffName||"Nurse");setEnc(next);router.push(`/doctor?encounter_id=${next.id}&name=${encodeURIComponent(next.name)}`)}
 if(!enc)return <div><h1 className="page-title">Nurse Screening</h1><p className="page-sub">เลือกผู้ป่วยจาก Patient Journey</p><div className="journey-grid">{rows.map(r=><button className="journey-card" key={r.id} onClick={()=>choose(r)}><strong>{r.name||`Visit ${r.id}`}</strong><span>{r.service}</span><small>Stage: {r.stage}</small></button>)}</div></div>;
 return <div><h1 className="page-title">Nurse Screening · {enc.name}</h1><p className="page-sub">Chief Complaint · ENT/ESI · Vitals · Visual Acuity · Nurse Note</p><WorkflowBar stage={enc.stage}/><form className="card" onSubmit={save}>
 <div className="section-title">Clinical Screening</div><div className="form-grid">
 <div className="field"><label>Chief Complaint *</label><input required value={f.chief_complaint} onChange={e=>setF({...f,chief_complaint:e.target.value})}/></div>
 <div className="field"><label>Duration</label><input value={f.duration} onChange={e=>setF({...f,duration:e.target.value})} placeholder="Today / 2 days"/></div>
 <div className="field"><label>ESI / Urgency</label><select value={f.esi} onChange={e=>setF({...f,esi:e.target.value})}>{[1,2,3,4,5].map(x=><option key={x}>{x}</option>)}</select></div>
 <div className="field"><label>Emergency Red Flags</label><select value={f.emergency_red_flags} onChange={e=>setF({...f,emergency_red_flags:e.target.value})}><option value="none">No red flag</option><option>Sudden vision loss</option><option>Chemical injury</option><option>Penetrating trauma</option><option>Severe eye pain</option><option>Neurologic deficit</option></select></div>
 </div>
 <div className="section-title">Vital Signs</div><div className="form-grid">{[["bp","BP (mmHg)"],["hr","HR"],["rr","RR"],["temp","Temp °C"],["spo2","SpO₂ %"],["pain","Pain 0–10"]].map(([k,l])=><div className="field" key={k}><label>{l}</label><input value={f[k]} onChange={e=>setF({...f,[k]:e.target.value})}/></div>)}</div>
 <div className="section-title">Eye / ENT Specialty Screening</div><div className="clinical-guide"><b>OD</b> = Right eye · <b>OS</b> = Left eye · <b>OU</b> = Both eyes</div><div className="form-grid">
 <div className="field"><label>Affected Eye</label><select value={f.eye_side} onChange={e=>setF({...f,eye_side:e.target.value})}><option>OD</option><option>OS</option><option>OU</option></select></div>
 <div className="field"><label>VA OD</label><select value={f.va_od} onChange={e=>setF({...f,va_od:e.target.value})}><option value="">Select VA</option>{VA.map(v=><option key={v}>{v}</option>)}</select></div>
 <div className="field"><label>VA OS</label><select value={f.va_os} onChange={e=>setF({...f,va_os:e.target.value})}><option value="">Select VA</option>{VA.map(v=><option key={v}>{v}</option>)}</select></div>
 <div className="field"><label>Eye symptoms</label><input value={f.eye_symptoms} onChange={e=>setF({...f,eye_symptoms:e.target.value})} placeholder="Pain, redness, blurred vision…"/></div>
 <div className="field"><label>ENT symptoms</label><input value={f.ent_symptoms} onChange={e=>setF({...f,ent_symptoms:e.target.value})} placeholder="Ear pain, hearing loss, nasal, throat…"/></div>
 <div className="field"><label>Allergy review</label><input value={f.allergy_review} onChange={e=>setF({...f,allergy_review:e.target.value})}/></div>
 </div><div className="field"><label>Nurse Note *</label><textarea required rows={4} value={f.nurse_note} onChange={e=>setF({...f,nurse_note:e.target.value})}/></div>
 <div className="flow-actions"><button className="btn btn-primary" type="submit">Save & Send to Doctor →</button></div></form></div>
}
export default function Nursing(){return <Suspense fallback={<div className="spinner-text">Loading…</div>}><Page/></Suspense>}
