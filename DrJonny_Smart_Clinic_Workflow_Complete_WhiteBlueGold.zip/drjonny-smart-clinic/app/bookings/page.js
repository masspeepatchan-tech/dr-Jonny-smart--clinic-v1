"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabaseClient";
import { useLanguage } from "../../lib/i18n";
import { ensureEncounter } from "../../lib/workflow";

const emptyForm = {
  name: "",
  phone: "",
  service: "",
  booking_date: new Date().toISOString().slice(0, 10),
  booking_time: "09:00",
  note: "",
  patient_id: "",
};

const STATUSES = ["pending", "confirmed", "done", "cancelled"];

export default function BookingsPage() {
  const { t } = useLanguage();
  const [bookings, setBookings] = useState([]);
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const [dateFilter, setDateFilter] = useState(new Date().toISOString().slice(0, 10));

  async function load() {
    setLoading(true);
    const { data } = await supabase
      .from("drjonny_bookings")
      .select("id, name, phone, service, booking_date, booking_time, status, note, patient_id")
      .order("booking_date", { ascending: false })
      .order("booking_time", { ascending: true })
      .limit(200);
    setBookings(data || []);
    const { data: pats } = await supabase.from("drjonny_patients").select("id, hn, name").order("name");
    setPatients(pats || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = dateFilter ? bookings.filter((b) => b.booking_date === dateFilter) : bookings;

  async function handleSave(e) {
    e.preventDefault();
    if (!form.name || !form.booking_date || !form.booking_time) return;
    setSaving(true);
    setError("");
    const payload = { ...form };
    if (!payload.patient_id) delete payload.patient_id;
    else payload.patient_id = Number(payload.patient_id);
    const { data: inserted, error } = await supabase.from("drjonny_bookings").insert(payload).select("id, patient_id, name, phone, service").single();
    setSaving(false);
    if (error) {
      setError(error.message);
      return;
    }
    if (inserted) ensureEncounter({ id: inserted.id, booking_id: inserted.id, patient_id: inserted.patient_id, name: inserted.name, phone: inserted.phone, service: inserted.service });
    setShowForm(false);
    setForm(emptyForm);
    load();
  }

  async function updateStatus(id, status) {
    setBookings((prev) => prev.map((b) => (b.id === id ? { ...b, status } : b)));
    await supabase.from("drjonny_bookings").update({ status }).eq("id", id);
  }

  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="page-title">{t("bookings")}</h1>
          <p className="page-sub">{filtered.length} {t("bookings").toLowerCase()}</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>
          + {t("new_booking")}
        </button>
      </div>

      <div className="field" style={{ maxWidth: 220, marginBottom: 16 }}>
        <label>{t("date")}</label>
        <input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} />
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>{t("time")}</th>
              <th>{t("name")}</th>
              <th>{t("phone")}</th>
              <th>{t("service")}</th>
              <th>{t("status")}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {!loading && filtered.length === 0 && (
              <tr><td colSpan={6} className="spinner-text">{t("no_data")}</td></tr>
            )}
            {filtered.map((b) => (
              <tr key={b.id}>
                <td>{b.booking_time?.slice(0, 5)}</td>
                <td>{b.name}</td>
                <td>{b.phone || "-"}</td>
                <td>{b.service || "-"}</td>
                <td>
                  <select
                    value={b.status}
                    onChange={(e) => updateStatus(b.id, e.target.value)}
                    style={{
                      padding: "4px 8px",
                      borderRadius: 8,
                      border: "1.5px solid var(--border)",
                      fontSize: 12,
                      fontWeight: 700,
                    }}
                  >
                    {STATUSES.map((s) => (
                      <option key={s} value={s}>
                        {t("status_" + s)}
                      </option>
                    ))}
                  </select>
                </td>
                <td>
                  <Link
                    href={`/nursing?booking_id=${b.id}&patient_id=${b.patient_id || ""}&name=${encodeURIComponent(b.name)}`}
                    className="link-btn"
                  >
                    Nurse Screening →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h2 style={{ marginTop: 0, color: "var(--navy)" }}>{t("new_booking")}</h2>
            <form onSubmit={handleSave}>
              <div className="form-grid">
                <div className="field">
                  <label>{t("patients")} ({t("hn")})</label>
                  <select
                    value={form.patient_id}
                    onChange={(e) => {
                      const pid = e.target.value;
                      const p = patients.find((x) => String(x.id) === pid);
                      setForm({ ...form, patient_id: pid, name: p ? p.name : form.name });
                    }}
                  >
                    <option value="">— {t("name")} manual —</option>
                    {patients.map((p) => (
                      <option key={p.id} value={p.id}>{p.hn} · {p.name}</option>
                    ))}
                  </select>
                </div>
                <div className="field">
                  <label>{t("name")} *</label>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("phone")}</label>
                  <input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("service")}</label>
                  <input
                    value={form.service}
                    onChange={(e) => setForm({ ...form, service: e.target.value })}
                    placeholder="Eye exam / OPD / Follow-up"
                  />
                </div>
                <div className="field">
                  <label>{t("date")} *</label>
                  <input
                    type="date"
                    required
                    value={form.booking_date}
                    onChange={(e) => setForm({ ...form, booking_date: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("time")} *</label>
                  <input
                    type="time"
                    required
                    value={form.booking_time}
                    onChange={(e) => setForm({ ...form, booking_time: e.target.value })}
                  />
                </div>
              </div>
              <div className="field" style={{ marginBottom: 16 }}>
                <label>{t("note")}</label>
                <textarea
                  rows={2}
                  value={form.note}
                  onChange={(e) => setForm({ ...form, note: e.target.value })}
                />
              </div>
              {error && <div className="note-box" style={{ marginBottom: 12 }}>{error}</div>}
              <div style={{ display: "flex", gap: 10 }}>
                <button className="btn btn-primary" type="submit" disabled={saving}>
                  {saving ? "…" : t("save")}
                </button>
                <button className="btn btn-outline" type="button" onClick={() => setShowForm(false)}>
                  {t("cancel")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
