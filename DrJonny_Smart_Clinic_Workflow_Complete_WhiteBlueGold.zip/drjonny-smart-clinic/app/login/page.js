"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { useLanguage } from "../../lib/i18n";
import { useRole, ROLES } from "../../lib/role";

const ROLE_META = {
  admin: "🛡️",
  doctor: "🩺",
  reception: "🗂️",
  pharmacy: "💊",
  cashier: "💵",
  nurse: "🩺",
};

export default function LoginPage() {
  const { t } = useLanguage();
  const { setRole, setStaffName } = useRole();
  const router = useRouter();
  const [selected, setSelected] = useState(null);
  const [name, setName] = useState("");

  const handleEnter = () => {
    if (!selected) return;
    setRole(selected);
    setStaffName(name);
    router.push(selected === "pharmacy" ? "/pharmacy" : selected === "cashier" ? "/billing" : selected === "nurse" ? "/nursing" : selected === "doctor" ? "/doctor" : "/dashboard");
  };

  return (
    <div className="login-wrap">
      <div>
        <div style={{ fontSize: 40, fontWeight: 800, color: "var(--navy)" }}>
          Dr. Jonny Smart Clinic
        </div>
        <div className="small-muted" style={{ marginTop: 6 }}>
          Vientiane, Laos — Full Clinic Operating System
        </div>
      </div>

      <div className="card" style={{ maxWidth: 720, width: "100%" }}>
        <div className="page-title" style={{ fontSize: 18, marginBottom: 16 }}>
          {t("select_role")}
        </div>
        <div className="role-grid">
          {ROLES.map((r) => (
            <div
              key={r}
              className={"role-tile" + (selected === r ? " selected" : "")}
              onClick={() => setSelected(r)}
            >
              <span className="role-emoji">{ROLE_META[r]}</span>
              {t("role_" + r)}
            </div>
          ))}
        </div>

        <div className="field" style={{ marginTop: 20, maxWidth: 320 }}>
          <label>{t("name")}</label>
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder={t("name")} />
        </div>

        <button
          className="btn btn-primary"
          style={{ marginTop: 16 }}
          disabled={!selected}
          onClick={handleEnter}
        >
          {t("enter")} →
        </button>

        <div className="note-box" style={{ marginTop: 18 }}>{t("role_gate_note")}</div>
      </div>
    </div>
  );
}
