"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabaseClient";
import { useLanguage } from "../../lib/i18n";

const emptyForm = {
  name: "",
  phone: "",
  dob: "",
  gender: "",
  address: "",
  allergies: "",
  chronic_conditions: "",
};

export default function PatientsPage() {
  const { t } = useLanguage();
  const [patients, setPatients] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    setLoading(true);
    const { data, error } = await supabase
      .from("drjonny_patients")
      .select("id, hn, name, phone, dob, gender, created_at")
      .order("created_at", { ascending: false });
    if (!error) setPatients(data || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = patients.filter((p) => {
    const q = search.toLowerCase();
    return (
      p.name?.toLowerCase().includes(q) ||
      p.hn?.toLowerCase().includes(q) ||
      p.phone?.toLowerCase().includes(q)
    );
  });

  async function handleSave(e) {
    e.preventDefault();
    if (!form.name) return;
    setSaving(true);
    setError("");
    const payload = { ...form };
    Object.keys(payload).forEach((k) => {
      if (payload[k] === "") payload[k] = null;
    });
    const { error } = await supabase.from("drjonny_patients").insert(payload);
    setSaving(false);
    if (error) {
      setError(error.message);
      return;
    }
    setShowForm(false);
    setForm(emptyForm);
    load();
  }

  return (
    <div>
      <div className="section-head">
        <div>
          <h1 className="page-title">{t("patients")}</h1>
          <p className="page-sub">{t("total_patients")}: {patients.length}</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowForm(true)}>
          + {t("add_patient")}
        </button>
      </div>

      <div className="field" style={{ maxWidth: 320, marginBottom: 16 }}>
        <input
          placeholder={t("search")}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>{t("hn")}</th>
              <th>{t("name")}</th>
              <th>{t("phone")}</th>
              <th>{t("dob")}</th>
              <th>{t("gender")}</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {!loading && filtered.length === 0 && (
              <tr>
                <td colSpan={6} className="spinner-text">{t("no_data")}</td>
              </tr>
            )}
            {filtered.map((p) => (
              <tr key={p.id}>
                <td>{p.hn}</td>
                <td>{p.name}</td>
                <td>{p.phone || "-"}</td>
                <td>{p.dob || "-"}</td>
                <td>{p.gender || "-"}</td>
                <td>
                  <Link href={`/patients/${p.id}`} className="link-btn">
                    {t("view")} →
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {showForm && (
        <div className="modal-overlay" onClick={() => setShowForm(false)}>
          <div className="modal-box" onClick={(e) => e.stopPropagation()}>
            <h2 style={{ marginTop: 0, color: "var(--navy)" }}>{t("add_patient")}</h2>
            <form onSubmit={handleSave}>
              <div className="form-grid">
                <div className="field">
                  <label>{t("name")} *</label>
                  <input
                    required
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("phone")}</label>
                  <input
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("dob")}</label>
                  <input
                    type="date"
                    value={form.dob}
                    onChange={(e) => setForm({ ...form, dob: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("gender")}</label>
                  <select
                    value={form.gender}
                    onChange={(e) => setForm({ ...form, gender: e.target.value })}
                  >
                    <option value="">-</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                  </select>
                </div>
                <div className="field">
                  <label>{t("allergies")}</label>
                  <input
                    value={form.allergies}
                    onChange={(e) => setForm({ ...form, allergies: e.target.value })}
                  />
                </div>
                <div className="field">
                  <label>{t("chronic")}</label>
                  <input
                    value={form.chronic_conditions}
                    onChange={(e) => setForm({ ...form, chronic_conditions: e.target.value })}
                  />
                </div>
              </div>
              <div className="field" style={{ marginBottom: 16 }}>
                <label>{t("address")}</label>
                <textarea
                  rows={2}
                  value={form.address}
                  onChange={(e) => setForm({ ...form, address: e.target.value })}
                />
              </div>
              {error && <div className="note-box" style={{ marginBottom: 12 }}>{error}</div>}
              <div style={{ display: "flex", gap: 10 }}>
                <button className="btn btn-primary" type="submit" disabled={saving}>
                  {saving ? "…" : t("save")}
                </button>
                <button
                  className="btn btn-outline"
                  type="button"
                  onClick={() => setShowForm(false)}
                >
                  {t("cancel")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
