"use client";
import { useEffect, useState } from "react";
import { useParams } from "next/navigation";
import { supabase } from "../../../lib/supabaseClient";
import { useLanguage } from "../../../lib/i18n";

export default function PatientDetailPage() {
  const { t } = useLanguage();
  const params = useParams();
  const id = params.id;
  const [patient, setPatient] = useState(null);
  const [bookings, setBookings] = useState([]);
  const [exams, setExams] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      setLoading(true);
      const [pRes, bRes, eRes] = await Promise.all([
        supabase.from("drjonny_patients").select("*").eq("id", id).single(),
        supabase
          .from("drjonny_bookings")
          .select("id, service, booking_date, booking_time, status")
          .eq("patient_id", id)
          .order("booking_date", { ascending: false }),
        supabase
          .from("drjonny_eye_exams")
          .select("id, diagnosis, examined_by, examined_at, visual_acuity_od, visual_acuity_os")
          .eq("patient_id", id)
          .order("examined_at", { ascending: false }),
      ]);
      setPatient(pRes.data || null);
      setBookings(bRes.data || []);
      setExams(eRes.data || []);
      setLoading(false);
    }
    if (id) load();
  }, [id]);

  if (loading) return <div className="spinner-text">{t("loading")}</div>;
  if (!patient) return <div className="spinner-text">{t("no_data")}</div>;

  return (
    <div>
      <h1 className="page-title">{patient.name}</h1>
      <p className="page-sub">{t("hn")}: {patient.hn}</p>

      <div className="grid-cards" style={{ gridTemplateColumns: "repeat(auto-fit,minmax(160px,1fr))" }}>
        <div className="card"><div className="stat-label">{t("phone")}</div>{patient.phone || "-"}</div>
        <div className="card"><div className="stat-label">{t("dob")}</div>{patient.dob || "-"}</div>
        <div className="card"><div className="stat-label">{t("gender")}</div>{patient.gender || "-"}</div>
        <div className="card"><div className="stat-label">{t("allergies")}</div>{patient.allergies || "-"}</div>
        <div className="card"><div className="stat-label">{t("chronic")}</div>{patient.chronic_conditions || "-"}</div>
        <div className="card"><div className="stat-label">{t("address")}</div>{patient.address || "-"}</div>
      </div>

      <h2 style={{ fontSize: 16, color: "var(--navy)" }}>{t("booking_history")}</h2>
      <div className="table-wrap" style={{ marginBottom: 24 }}>
        <table>
          <thead>
            <tr><th>{t("date")}</th><th>{t("time")}</th><th>{t("service")}</th><th>{t("status")}</th></tr>
          </thead>
          <tbody>
            {bookings.length === 0 && (
              <tr><td colSpan={4} className="spinner-text">{t("no_data")}</td></tr>
            )}
            {bookings.map((b) => (
              <tr key={b.id}>
                <td>{b.booking_date}</td>
                <td>{b.booking_time?.slice(0,5)}</td>
                <td>{b.service || "-"}</td>
                <td><span className={"badge badge-" + b.status}>{t("status_" + b.status)}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <h2 style={{ fontSize: 16, color: "var(--navy)" }}>{t("exam_history")}</h2>
      <div className="table-wrap">
        <table>
          <thead>
            <tr><th>{t("date")}</th><th>{t("od")}</th><th>{t("os")}</th><th>{t("diagnosis")}</th><th>{t("examined_by")}</th></tr>
          </thead>
          <tbody>
            {exams.length === 0 && (
              <tr><td colSpan={5} className="spinner-text">{t("no_data")}</td></tr>
            )}
            {exams.map((ex) => (
              <tr key={ex.id}>
                <td>{ex.examined_at?.slice(0,10)}</td>
                <td>{ex.visual_acuity_od || "-"}</td>
                <td>{ex.visual_acuity_os || "-"}</td>
                <td>{ex.diagnosis || "-"}</td>
                <td>{ex.examined_by || "-"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
