"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../../lib/supabaseClient";
import { useLanguage } from "../../lib/i18n";
import { listEncounters, STAGES } from "../../lib/workflow";

function todayStr() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

export default function DashboardPage() {
  const { t } = useLanguage();
  const [stats, setStats] = useState({
    todayBookings: 0,
    lowStock: 0,
    todayRevenue: 0,
    totalPatients: 0,
  });
  const [recentBookings, setRecentBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [encounters, setEncounters] = useState([]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      setLoading(true);
      const today = todayStr();

      const [bookingsRes, stockRes, txRes, patientsRes, recentRes] = await Promise.all([
        supabase
          .from("drjonny_bookings")
          .select("id", { count: "exact", head: true })
          .eq("booking_date", today),
        supabase.from("drjonny_drug_stock").select("id, quantity, reorder_level"),
        supabase
          .from("drjonny_transactions")
          .select("amount, status, created_at")
          .gte("created_at", `${today}T00:00:00`)
          .eq("status", "paid"),
        supabase.from("drjonny_patients").select("id", { count: "exact", head: true }),
        supabase
          .from("drjonny_bookings")
          .select("id, name, service, booking_date, booking_time, status")
          .eq("booking_date", today)
          .order("booking_time", { ascending: true })
          .limit(6),
      ]);

      if (cancelled) return;

      const lowStock = (stockRes.data || []).filter(
        (d) => Number(d.quantity) <= Number(d.reorder_level)
      ).length;
      const revenue = (txRes.data || []).reduce((sum, r) => sum + Number(r.amount || 0), 0);

      setStats({
        todayBookings: bookingsRes.count || 0,
        lowStock,
        todayRevenue: revenue,
        totalPatients: patientsRes.count || 0,
      });
      setRecentBookings(recentRes.data || []);
      setEncounters(listEncounters());
      setLoading(false);
    }
    load();
    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div>
      <h1 className="page-title">{t("dashboard")}</h1>
      <p className="page-sub">Dr. Jonny Smart Clinic — {todayStr()}</p>

      <div className="grid-cards">
        <div className="stat-card">
          <div className="stat-label">{t("today_bookings")}</div>
          <div className="stat-value">{loading ? "…" : stats.todayBookings}</div>
        </div>
        <div className={"stat-card" + (stats.lowStock > 0 ? " danger" : "")}>
          <div className="stat-label">{t("low_stock")}</div>
          <div className="stat-value">{loading ? "…" : stats.lowStock}</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">{t("today_revenue")}</div>
          <div className="stat-value">
            {loading ? "…" : stats.todayRevenue.toLocaleString()} ₭
          </div>
        </div>
        <div className="stat-card">
          <div className="stat-label">{t("total_patients")}</div>
          <div className="stat-value">{loading ? "…" : stats.totalPatients}</div>
        </div>
      </div>


      <div className="section-head" style={{marginTop:24}}>
        <div><h2 style={{margin:0,fontSize:16,color:"var(--navy)"}}>Live Patient Journey</h2><p className="page-sub" style={{margin:0}}>Real-time encounter board in this browser session</p></div>
      </div>
      <div className="journey-board">
        {encounters.filter(e=>e.stage!=="closed").slice(0,12).map(e=><div className="journey-line" key={e.id}><div><strong>{e.name||`Visit ${e.id}`}</strong><small>{e.service||"Eye / ENT"}</small></div><div className="journey-progress">{STAGES.map(s=><span key={s} className={STAGES.indexOf(s)<=STAGES.indexOf(e.stage)?"on":""}></span>)}</div><b>{e.stage}</b></div>)}
        {encounters.filter(e=>e.stage!=="closed").length===0&&<div className="spinner-text">No active patient journey yet</div>}
      </div>

      <div className="section-head">
        <h2 style={{ margin: 0, fontSize: 16, color: "var(--navy)" }}>{t("today_bookings")}</h2>
        <Link href="/bookings" className="link-btn">
          {t("bookings")} →
        </Link>
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>{t("time")}</th>
              <th>{t("name")}</th>
              <th>{t("service")}</th>
              <th>{t("status")}</th>
            </tr>
          </thead>
          <tbody>
            {recentBookings.length === 0 && !loading && (
              <tr>
                <td colSpan={4} className="spinner-text">
                  {t("no_data")}
                </td>
              </tr>
            )}
            {recentBookings.map((b) => (
              <tr key={b.id}>
                <td>{b.booking_time?.slice(0, 5)}</td>
                <td>{b.name}</td>
                <td>{b.service || "-"}</td>
                <td>
                  <span className={"badge badge-" + b.status}>{t("status_" + b.status)}</span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
