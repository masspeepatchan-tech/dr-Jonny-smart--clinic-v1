# Doctor Jonny Smart Eye Clinic OS — Vercel Ready

This version has **no npm/build dependency**. It is a static HTML/CSS/JavaScript application that can be deployed directly to Vercel.

## Implemented workflow
Registration → Queue → ENT/ESI + emergency/red-flag screening → Vital signs → Visual acuity → Nurse note → Doctor Jonny examination / Doctor note / diagnosis / treatment → Follow-up → Prescription / Pharmacy → Finance → Payment Gate → Medication Dispensing → Discharge.

Also implemented:
- Module dashboard
- Realtime-style Record Board
- Patient history / encounter state
- QP / SOP / WI / QF / QI document-control module
- Audit trail
- Payment-before-dispense safety gate
- Discharge completion gate
- Browser persistence via localStorage
- Cross-tab refresh via storage events

## Deploy
Upload this folder to a GitHub repository and import it in Vercel, or upload/import the folder through your preferred Vercel workflow. No build command is required.

## Important production note
This release is a **functional local-first clinic build**, suitable for workflow demo, UAT, training, and single-device/single-browser operation. Data is stored in browser localStorage, not a production clinical database.

Before real patient use, add a secure backend/database, authenticated users, server-side RBAC, encryption, backups, PDPA controls, immutable server audit logs, clinical governance validation, medication master data and tested disaster recovery.

Clinical alerts and ESI-style urgency fields are decision-support only; final clinical decisions stay with authorized healthcare professionals.
